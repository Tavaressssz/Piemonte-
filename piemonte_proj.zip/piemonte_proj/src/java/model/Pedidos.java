package model;

import java.util.Date;
import java.util.List;

public class Pedidos {

    private int id;
    private Date data;
    private int cliente;
    private List<Prato> pratos;
    private double total;

    public Pedidos(Date data, int cliente, List<Prato> pratos, double total) {
        this.data = data;
        this.cliente = cliente;
        this.pratos = pratos;
        this.total = total;
    }

    public Pedidos(int id, Date data, int cliente, List<Prato> pratos, double total) {
        this.id = id;
        this.data = data;
        this.cliente = cliente;
        this.pratos = pratos;
        this.total = total;
    }

    public Pedidos() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public int getCliente() {
        return cliente;
    }

    public void setCliente(int cliente) {
        this.cliente = cliente;
    }

    public List<Prato> getPratos() {
        return pratos;
    }

    public void setPratos(List<Prato> pratos) {
        this.pratos = pratos;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    @Override
    public String toString() {
        return "Pedidos{" + "id=" + id + ", data=" + data + ", cliente=" + cliente + ", pratos=" + pratos + ", total=" + total + '}';
    }

}
