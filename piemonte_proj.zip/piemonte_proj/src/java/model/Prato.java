
package model;


public class Prato {
    private int id;
    private String prato;
    private String descricao;
    private double valor;
    private Categoria categoria;

    public Prato(String prato, String descricao, double valor, Categoria categoria) {
        this.prato = prato;
        this.descricao = descricao;
        this.valor = valor;
        this.categoria = categoria;
    }

    public Prato(int id, String prato, String descricao, double valor, Categoria categoria) {
        this.id = id;
        this.prato = prato;
        this.descricao = descricao;
        this.valor = valor;
        this.categoria = categoria;
    }
    
    public Prato(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPrato() {
        return prato;
    }

    public void setPrato(String prato) {
        this.prato = prato;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return "Prato{" + "id=" + id + ", prato=" + prato + ", descricao=" + descricao + ", valor=" + valor + ", categoria=" + categoria + '}';
    }
    
    
}
