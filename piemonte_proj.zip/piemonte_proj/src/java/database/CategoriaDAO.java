package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Categoria;
import model.Usuario;

public class CategoriaDAO {
    private static Connection conn;

public CategoriaDAO() throws ClassNotFoundException, SQLException {
        conn = Conexao.getConn();
    }
    
    public ArrayList<Categoria> getAllCategories() throws SQLException {
        
        ArrayList<Categoria> list = new ArrayList();
        
        String query = "select * from categorias;";
        
        PreparedStatement prep = conn.prepareStatement(query);
        
        ResultSet res = prep.executeQuery();
        
        while( res.next() ) {
            Categoria cat = new Categoria();
            
            cat.setId( res.getInt("id") );
            cat.setCategoria(res.getString("categoria") );
            
            list.add(cat);
            System.out.println(cat);
        }
        
        prep.close();
        return list;
    }
    
    
    public void setNewUser(Categoria cat) throws SQLException {
        String query = "insert into categorias(categoria) "
                     + "values(?)";
        
        PreparedStatement prep = conn.prepareStatement(query);
        
        prep.setString(1, cat.getCategoria() );
                
        prep.execute();
        prep.close();
    }
    
    
    public void deleteCategory(int id) throws SQLException {
        String query = "delete from categorias "
                     + "where id = " + id ;
        
        PreparedStatement prep = conn.prepareStatement(query);
        
        prep.execute();
        prep.close();
    }
    
    
    public Categoria getOneCategory(int id) throws SQLException {
        String query = "select * from categorias where id = " + id;
        
        PreparedStatement prep = conn.prepareStatement(query);
        
        ResultSet res = prep.executeQuery();
        
        Categoria cat = new Categoria();
        
        if( res.next() ) {
            cat.setId(id);
            cat.setCategoria(res.getString("categoria"));
        }
        
        prep.close();
        return cat;
    }
    
       
    
    public void updateCategory(Categoria cat) throws SQLException {
        String query = "update categorias set categoria = ? where id = ?";
        
        PreparedStatement prep = conn.prepareStatement(query);
        
        prep.setString(1, cat.getCategoria() );
        prep.setInt(2, cat.getId() );
        
        prep.execute();
        prep.close();
    }
}

