
package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Prato;


public class PratoDAO {
        private static Connection conn;

public PratoDAO() throws ClassNotFoundException, SQLException {
        conn = Conexao.getConn();
    }
    
    public ArrayList<Prato> getAllPratos() throws SQLException {
        
        ArrayList<Prato> list = new ArrayList();
        
        String query = "select * from pratos;";
        
        PreparedStatement prep = conn.prepareStatement(query);
        
        ResultSet res = prep.executeQuery();
        
        while( res.next() ) {
            Prato prat = new Prato();
            
            prat.setId( res.getInt("id") );
            prat.setPrato(res.getString("prato") );
            prat.setDescricao( res.getString("descricao") );
            prat.setValor(res.getDouble("valor"));
            
            
            list.add(prat);
            System.out.println(prat);
        }
        
        prep.close();
        return list;
    }
    
    
    public void setNewUser(Prato prat) throws SQLException {
        String query = "insert into categorias(categoria) "
                     + "values(?)";
        
        PreparedStatement prep = conn.prepareStatement(query);
        
        prep.setString(1, prat.getPrato());
                
        prep.execute();
        prep.close();
    }
    
    
    public void deleteCategory(int id) throws SQLException {
        String query = "delete from pratos "
                     + "where id = " + id ;
        
        PreparedStatement prep = conn.prepareStatement(query);
        
        prep.execute();
        prep.close();
    }
    
    
    public Prato getOnePratos(int id) throws SQLException {
        String query = "select * from pratos where id = " + id;
        
        PreparedStatement prep = conn.prepareStatement(query);
        
        ResultSet res = prep.executeQuery();
        
        Prato prat = new Prato();
        
        if( res.next() ) {
            prat.setId(id);
            prat.setPrato(res.getString("pratos"));
        }
        
        prep.close();
        return prat;
    }
    
       
    
    public void updatePrato(Prato prat) throws SQLException {
        String query = "update categorias set categoria = ? where id = ?";
        
        PreparedStatement prep = conn.prepareStatement(query);
        
        prep.setString(1, prat.getPrato() );
        prep.setInt(2, prat.getId() );
        
        prep.execute();
        prep.close();
    }
}
