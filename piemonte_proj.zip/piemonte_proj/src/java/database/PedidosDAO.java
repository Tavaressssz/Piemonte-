package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Pedidos;
import model.Prato;

public class PedidosDAO {
    
    private static Connection conn;
    
    public PedidosDAO() throws ClassNotFoundException, SQLException {
        conn = Conexao.getConn();
    }
    
    public ArrayList<Pedidos> getAllPedidos() throws SQLException {
        
        ArrayList<Pedidos> list = new ArrayList();
        
        String query = "select * from pedidos;";
        
        PreparedStatement prep = conn.prepareStatement(query);
        
        ResultSet res = prep.executeQuery();
        
        while (res.next()) {
            Pedidos ped = new Pedidos();
            
            ped.setId(res.getInt("id"));
            ped.setData(res.getDate("data_pedido"));
            ped.setCliente(res.getInt("cliente"));
            
            list.add(ped);
            System.out.println(ped);
        }
        
        prep.close();
        return list;
    }
    
    public void setNewUser(Pedidos ped) throws SQLException {
        String query = "insert into categorias(categoria) "
                + "values(?)";
        
        PreparedStatement prep = conn.prepareStatement(query);
        
        prep.setDouble
        (1, ped.getTotal());
        
        prep.execute();
        prep.close();
    }
    
    public void deleteCategory(int id) throws SQLException {
        String query = "delete from pedidos "
                + "where id = " + id;
        
        PreparedStatement prep = conn.prepareStatement(query);
        
        prep.execute();
        prep.close();
    }
    
    public Pedidos getOnePedidos(int id) throws SQLException {
        String query = "select * from pedidos where id = " + id;
        
        PreparedStatement prep = conn.prepareStatement(query);
        
        ResultSet res = prep.executeQuery();
        
        Pedidos ped = new Pedidos();
        
        if (res.next()) {
            ped.setId(id);
            ped.setData(res.getDate("data_pedido"));
            ped.setCliente(res.getInt("cliente"));
            ped.setPratos((List<Prato>) res.getObject("pratos"));
            ped.setTotal(res.getDouble("total"));
        }
        
        prep.close();
        return ped;
    }
    
    public void updatePedidos(Pedidos ped) throws SQLException {
        String query = "update categorias set categoria = ? where id = ?";
        
        PreparedStatement prep = conn.prepareStatement(query);
        
        prep.setDouble(1, ped.getTotal());
        prep.setInt(2, ped.getId());
        
        prep.execute();
        prep.close();
    }
    
}
